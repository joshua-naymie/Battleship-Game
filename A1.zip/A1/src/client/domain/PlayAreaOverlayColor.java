package client.domain;

public enum PlayAreaOverlayColor
{
	RED,
	GREEN
}