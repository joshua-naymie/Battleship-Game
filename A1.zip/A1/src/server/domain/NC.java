package server.domain;

//Network Commands **NOT FINISHED**
public final class NC
{
	public static final
	byte UPDATE_OBSERVERS = 0,
		 CHANGE_NAME = 1,
		 END_SESSION = 2,
		 ERROR = 10;
}