Flight Reservation Managment System (FRMS)


March 27, 2021

Mohamed, Raphael, Jordan, Altamish


The FRMS is designed to help people book flights and professionally manage reservations of all airline tickets and passengers who would like to create transactions.
 This record keeping system allows you to find flights, choose a flight, enter passenger information, and modify an existing reservation.



List of deficiencies : NONE



How to run the program: 
	locate the jar file "assignment2.jar"
	open powershell and type: 
		 java -jar .\assignmnet2.jar
	
the GUI will start


